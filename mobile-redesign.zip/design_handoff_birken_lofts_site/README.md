# Handoff: Birken Lofts Website Redesign

## Overview
A redesign of birkenlofts.com (Birken Lofts — 57 loft residences in the 1905 S. Birkenstein & Sons Building, 401 W. Ontario St, River North, Chicago). Four pages: Home, History, Journal (blog index), and a Journal post template. The redesign replaces the previous light "cartoonish" theme with a dark, crisp, industrial-era look driven by the building's 1905 heritage.

Key decisions from stakeholder feedback (already applied in these designs):
- Dark/black theme; full-bleed building-facade hero (no circular crop).
- Industrial-period typography.
- **Removed entirely:** Finishes page, traffic-cam page, and any link to them; no mention of the highway on-ramp anywhere.
- **No interior "inspiration" photography** — only the real facade, floor plans, archival images, and one owner-supplied kitchen photo in a "Coming soon" Finishes teaser (no link).
- Custom neighborhood map with corrected geography (Chicago River North Branch runs WEST of the building; Whole Foods at Chicago & State).

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to ship. Recreate these designs in the target codebase's existing environment (the live site's current stack) using its established patterns. If no environment exists yet, choose an appropriate framework (e.g., a static-site generator or Next.js) and implement there. Open each file in a browser to see the rendered design; the meaningful markup is inside the `<x-dc>` element, with all styling inline.

## Fidelity
**High-fidelity.** Colors, type, spacing, and copy are final unless noted. Recreate pixel-perfectly. The only placeholder content is the Journal: the three post entries and the post body are sample copy — swap in the real posts (exclude the old post that linked to the Finishes page).

## Design Tokens
Colors:
- Page background: `#121110`; darker band background: `#0C0B0A`
- Card/surface: `#1B1917`; map background: `#14120F`
- Primary text: `#EDE6DB`; body text: `#C4BBAC`; muted: `#A79E90`; faint: `#8F8677`
- Accent (brick red): `#C86B4F`; accent hover: `#E08A6D`; marker/selection: `#B4553C`
- Paper (floor-plan card wells): `#F2EDE4`
- Hairline borders: `rgba(237,230,219,0.12)` (0.14 on images/map, 0.18 on inputs)
- Status green (schedule "Complete"): `#8A9B7C`
- Map: river `#26333A` (34px band) with `#3E5560` centerline; streets `#3A362F`; street labels `#6E675B`; POI labels `#B0A793`; POI dots stroke `#8A7B5C`; river labels `#5D7885`

Typography (Google Fonts):
- Headings: `Big Shoulders Display` 700/800, UPPERCASE, tight line-height (0.95–1.05)
- Body/UI: `Libre Franklin` 300 (body), 500/600 (labels/buttons); nav & buttons UPPERCASE 12–13px with 0.14–0.16em letter-spacing
- H1: `clamp(52px, 7vw, 92px)` (Home hero up to 112px); H2: `clamp(34px, 5vw, 52px)`; History/post section H2: `clamp(30px, 4.5vw, 40px)`; stats: 56px; body: 15–17px/1.6–1.8; ledes: 19–20px 300

Other:
- **No border radius anywhere** (sharp, crisp edges). No shadows — hairline borders instead.
- Content max-widths: 1200px (Home/Journal/footer), 1060px (History article), 980px (Journal post)
- Section vertical padding: `clamp(64px, 9vw, 104px)` top / `clamp(56px, 8vw, 96px)` bottom (approx.); horizontal `clamp(20px, 4vw, 32px)`
- Links default to accent `#C86B4F`, hover `#E08A6D`; selection background `#B4553C`

## Screens / Views

### 1. Home (`Home.dc.html`)
Sticky header (72px, `rgba(18,17,16,0.92)` + blur, bottom hairline): wordmark left (Big Shoulders 800, 24px, uppercase); nav right: Residences, History, Amenities, Neighborhood, Journal (muted `#A79E90`, hover `#EDE6DB`), plus a filled "Contact us" button (cream bg `#EDE6DB`, dark text, hover accent). Nav wraps on mobile.

Sections in order:
1. **Hero** — full-bleed facade photo (`min-height: min(88vh, 900px)`, `object-position: center 30%`), bottom-heavy dark gradient overlay (0.85 at bottom — tweakable), eyebrow line with 40px accent rule + "401 W. Ontario Street · River North, Chicago", H1 "Historic timber lofts in the heart of River North", 19px lede, two buttons (filled cream "View floor plans", outlined "Contact us").
2. **Stats band** — 4 columns (auto-fit minmax 220px), hairline separators: 1905 / 57 / 4 / 0.2 mi with uppercase captions.
3. **Floor plans** — heading row (H2 left, muted intro right); 3 cards (auto-fit minmax 260px): paper-white well (`#F2EDE4`, 24px padding, min-height 280px) with plan image `object-fit: contain`, then dark body: accent eyebrow "Interest list open", 32px title (Studio / One bedroom / Two bedroom), muted spec line, "Inquire →" link with accent underline. Card: `#1B1917` + hairline border.
4. **Finishes (Coming soon)** — 2-col split (image 360px+ / text), kitchen photo (`images/finishes-kitchen.png`) with hairline border; right: bordered accent badge "COMING SOON" (11px/0.2em, 8×14px padding), H2 "Finishes", body: "Charcoal stone, warm cabinetry, satin nickel — we're dialing in the finish selections now and will share them here once they're final." **No link.**
5. **History teaser** — darker band `#0C0B0A`; 2-col: accent eyebrow "Since 1905", H2 "The House of Birkenstein", body paragraph, link "Read the building's story →" (accent-underlined); right: B&W facade photo with an offset accent-outline frame (1px `rgba(200,107,79,0.5)`, shifted -14px left/bottom).
6. **Amenities** — 6 cells in a hairline-bordered grid (auto-fit minmax 260px): numbered 01–06 (accent, Big Shoulders 14px) + name. Items: Exposed brick & heavy timber; Oversized windows; In-unit laundry; Fitness center; Garage parking; Pet friendly.
7. **Neighborhood** — darker band; heading row (H2 "River North" + intro); custom SVG map (see below); 3 columns beneath with 2px accent top rules: Eat & drink / Transit / Outside. Transit copy: "Brown & Purple Lines at Chicago Ave., six minutes to the Loop." (**deliberately no mention of the 90/94 ramp**).
8. **Construction schedule** — 4 columns with hairline separators: status eyebrow (Complete `#8A9B7C` ×2, Next accent, Planned muted), 34px date (2025, Early 2026, Oct 2026, Oct 2027), title + body.
9. **Contact** — darker band; 2-col: left H2 + intro + address block with 2px accent left rule; right form grid (Name, Email, Phone, "Interested in" select [Studio / One bedroom / Two bedroom / Not sure yet], full-width Message textarea, filled "Send message" button). Inputs: `#14120F` bg, hairline border, focus border accent.
10. **Footer** — wordmark + "S. Birkenstein & Sons Building · Built 1905 / 401 W. Ontario Street, Chicago, IL 60654"; links: Residences, History, Journal, Contact.

#### Neighborhood map (SVG, 950×560 viewBox)
Schematic dark map, not a tile map. Geography requirements:
- River North Branch is a 34px `#26333A` band curving from top-left down the WEST side of the building, bending east below Kinzie into the Main Branch running along the bottom ("RIVERWALK · MAIN BRANCH" label).
- E–W streets top→bottom: Chicago Ave, Superior, Huron, Erie, Ontario, Ohio, Grand, Kinzie. N–S streets left→right: Sedgwick, Orleans, Franklin, Wells, LaSalle, Clark, Dearborn, State. Street labels 11px `#6E675B`, right-edge gutter for E–W names, rotated 90° on-line for N–S names; **all labels get a background-color halo** (`paint-order: stroke`, 5px `#14120F` stroke) so nothing collides.
- Building marker: 26px accent square with cream outline at Ontario × Sedgwick + "BIRKEN LOFTS / 401 W. ONTARIO ST".
- POIs (dot = 6px circle, `#8A7B5C` stroke): CHICAGO (BROWN LINE) at Chicago × Franklin; WHOLE FOODS at Chicago × State; WARD PARK on the river at ~Erie; EAST BANK CLUB at Kingsbury × Kinzie; MERCHANDISE MART on the Main Branch at Wells; GALLERY DISTRICT & DINING at Ohio × Clark.
- **Do not add** a highway ramp or traffic-cam reference.

### 2. History (`History.dc.html`)
Same header/footer (History nav item active: cream text + accent underline). Dark article page, 1060px column:
- Hero band (`#0C0B0A`): eyebrow "Since 1905" with accent rule, H1 "The House of Birkenstein", 20px lede.
- Article sections (72px gaps), each: 40px H2 + 17px/1.8 body ¶s. Sections: Smokey Hollow; A rag peddler's empire (text + Louis Birkenstein portrait figure, flex 240–320px, stacks on mobile); The house that Birkenstein built; War and the scrap boom; After Birkenstein; Birken Lofts today. Full copy is in the design file — use it verbatim.
- Figures: full-width image, hairline border, 13px italic muted captions (Sanborn map 1906, Louis Birkenstein 1919, "Hey Joe!" 1916 ad, House of Birkenstein 1920 ad, timber ceiling).
- CTA band: centered 34px "See what the House of Birkenstein holds now" + filled/outlined button pair.

### 3. Journal index (`Journal.dc.html`)
- Hero band: eyebrow "Notes from 401 W. Ontario" + accent rule, H1 "JOURNAL", lede "Progress on the building's conversion, finds from the archives, and life in River North."
- Entry list: full-width rows divided by hairlines, each row (flex, wraps on mobile): 220×150 thumbnail (`object-fit: cover`, hairline border, `saturate(0.9)`), then date eyebrow, 32px Big Shoulders title, 15px muted excerpt (max 640px), and an accent "READ →" at the right. Row hover: `rgba(237,230,219,0.03)` background. Entire row is the link.
- Current three entries are **sample copy**; replace with real posts. Do not include the old finishes-inspiration post.

### 4. Journal post template (`Journal Post.dc.html`)
- Header band (`#0C0B0A`, 980px column): "← JOURNAL" back link, H1, meta row "JUNE 2026 • CONSTRUCTION UPDATE" (accent bullet).
- Body (980px): 20px lede in primary color; 17px/1.8 body in `#C4BBAC`; pull-quote style (2px accent left rule, 20px italic 300); figure with caption; end matter: hairline divider + "Join the interest list" (filled) and "More from the Journal" (outlined).

## Interactions & Behavior
- Hovers: nav links muted→cream; filled buttons cream→accent bg; outlined buttons gain `rgba(237,230,219,0.1)` bg + full-opacity border; journal rows get faint bg; form fields focus to accent border. No animations/transitions otherwise; smooth scrolling for in-page anchors.
- Navigation: single-page anchors on Home (#plans, #amenities, #neighborhood, #contact); History and Journal are separate pages; contact CTAs everywhere target Home #contact.
- Contact form: not wired in the prototype. Implement submission per site's existing handler; all fields optional-looking but validate email format and require name + email; "Interested in" select options as listed.
- Responsive: fluid — grids use `auto-fit minmax(...)`, type and padding use `clamp()`. Verify at ~375px, ~768px, ~1280px.

## Mobile (`Mobile.dc.html`)
Explicit ~390px mobile designs for every page (frames 1a–1e on one canvas). Where mobile differs from a naive collapse of the desktop layout:
- **Header (all pages):** 60px tall; wordmark left + hamburger right (three 2px lines, 24px wide). No inline nav links on mobile.
- **Menu (frame 1b):** full-screen overlay on `#0C0B0A` — close (X) replaces the hamburger; nav items as big Big Shoulders 44px uppercase links with hairline dividers and 01–05 index numerals right-aligned; filled "Contact us" button + address line pinned at the bottom.
- **Home hero:** ~560px tall, `object-position: 62% 30%` (keeps the building centered on the narrow crop); eyebrow shortens to "River North, Chicago"; H1 46px; buttons stack full-width.
- **Stats:** 2×2 grid with hairline separators, 40px numerals.
- **Floor plans / finishes / history teaser / contact:** single column, stacked; buttons full-width; finishes image above text.
- **Amenities:** single-column hairline list (numeral + name per row).
- **Map:** dedicated portrait SVG variant (390×470 viewBox) — same geography rules, reduced street set (Chicago/Ontario/Ohio/Grand/Kinzie × Sedgwick/Orleans/Franklin/Wells), 10px labels with halo, POIs: Brown Line, Whole Foods, Ward Park, East Bank Club, Merchandise Mart. Use this variant below ~640px instead of scaling the desktop map (labels become illegible).
- **Construction schedule:** vertical timeline — square status dot + 1px connector line on the left, content right.
- **Journal index:** cards stack — full-width 190px-tall thumbnail above date/title/excerpt/READ →.
- **History/post articles:** single column; portrait figures center at reduced width; type steps down (H1 38–44px, H2 30px, body 15px). The History mobile frame shows the first two sections as the pattern — remaining sections repeat it with the full desktop copy.
- Hit targets ≥44px throughout (nav rows, buttons, form fields).

## State Management
None beyond form state. (The prototype exposes two design-review tweaks — hero overlay opacity, schedule section toggle — which do not need to be implemented.)

## Assets
- Live-site images referenced by URL (already in production at birkenlofts.com): facade color `/images/elevations/401-W-Ontario-No-Signs-1920w.webp` (hero) and `-1024w` (journal thumb); facade B&W `-Black-White-800w.webp`; floor plans `/images/floor-plans/...108.webp`, `...Unit-111.webp`, `...Unit-202.webp`; history images `/images/history/sanborn-map-1906.webp`, `louis-birkenstein-1919.webp`, `hey-joe-ad-1916.webp`, `house-of-birkenstein-ad-1920.webp`, `timber-ceiling.webp`.
- `images/finishes-kitchen.png` (in this bundle) — owner-supplied kitchen photo for the Finishes "Coming soon" section. Source a higher-resolution original if available (this was cropped from a screenshot).
- Fonts: Google Fonts — Big Shoulders Display (500–800), Libre Franklin (300–600 + italics).

## Files
- `Home.dc.html` — home page design
- `History.dc.html` — history page design
- `Journal.dc.html` — blog index design
- `Journal Post.dc.html` — blog post template design
- `Mobile.dc.html` — mobile (~390px) designs for all pages, incl. menu overlay and portrait map variant
- `images/finishes-kitchen.png` — finishes teaser photo
